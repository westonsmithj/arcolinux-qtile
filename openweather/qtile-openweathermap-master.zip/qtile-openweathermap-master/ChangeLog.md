# Change Log

## 0.2

### Changed

- Updated to handle QTile's removal of the `base.ThreadedPollText` class.

## 0.1

- Initial version
